#define COUNTERPART_ENV_NAME "GIT_SSH_PUSH"
#define COUNTERPART_PROGRAM_NAME "git-ssh-push"
#define MY_PROGRAM_NAME "git-ssh-pull"
#include "ssh-fetch.c"
