#ifndef REACHEABLE_H
#define REACHEABLE_H

extern void mark_reachable_objects(struct rev_info *revs, int mark_reflog);

#endif
